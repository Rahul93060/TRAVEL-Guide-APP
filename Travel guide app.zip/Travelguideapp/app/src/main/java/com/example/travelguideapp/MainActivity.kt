package com.example.travelguideapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.*
import androidx.navigation.NavController
import androidx.navigation.compose.*
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            TravelGuideApp()
        }
    }
}

// 🔹 App Navigation
@Composable
fun TravelGuideApp() {
    val navController = rememberNavController()

    NavHost(navController = navController, startDestination = "splash") {

        composable("splash") {
            SplashScreen(navController)
        }

        composable("home") {
            HomeScreen()
        }
    }
}


@Composable
fun SplashScreen(navController: NavController) {

    LaunchedEffect(Unit) {
        delay(5000) // 5 seconds delay
        navController.navigate("home") {
            popUpTo("splash") { inclusive = true }
        }
    }

    Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier.fillMaxSize()
    ) {
        Text(
            text = "Welcome to Travel Guide App ",
            fontSize = 28.sp
        )
    }
}


@Composable
fun HomeScreen() {

    val cities = listOf(
        "Delhi",
        "Mumbai",
        "Jaipur",
        "Amritsar",
        "Hyderabad",
        "Chandigarh",
        "Bangalore",
        "Chennai",
        "Kolkata",
        "Pune",
        "Ahmedabad",
        "Jaipur",
        "Lucknow",
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {

        Text(
            text = "Tourist Cities",
            fontSize = 24.sp
        )

        Spacer(modifier = Modifier.height(10.dp))

        LazyColumn {
            items(cities) { city ->

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(8.dp)
                ) {
                    Text(
                        text = city,
                        modifier = Modifier.padding(16.dp),
                        fontSize = 20.sp
                    )
                }
            }
        }
    }
}